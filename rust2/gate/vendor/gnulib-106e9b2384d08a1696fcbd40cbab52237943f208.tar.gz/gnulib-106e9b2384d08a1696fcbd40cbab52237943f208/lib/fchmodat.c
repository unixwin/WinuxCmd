/* Change the protections of file relative to an open directory.
   Copyright (C) 2006, 2009-2026 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* written by Jim Meyering and Paul Eggert */

/* If the user's config.h happens to include <sys/stat.h>, let it include only
   the system's <sys/stat.h> here, so that orig_fchmodat doesn't recurse to
   rpl_fchmodat.  */
#define __need_system_sys_stat_h
#include <config.h>

/* Get the original definition of fchmodat.  */
#include <sys/stat.h>
#undef __need_system_sys_stat_h

#if HAVE_FCHMODAT
static int
orig_fchmodat (int dir, char const *file, mode_t mode, int flags)
{
  return fchmodat (dir, file, mode, flags);
}
#endif

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Specification.  */
#include <sys/stat.h>

#include <intprops.h>

#include "issymlinkat.h"

#ifndef AT_EMPTY_PATH
# define AT_EMPTY_PATH 0
#endif

/* Invoke chmod or lchmod on FILE, using mode MODE, in the directory
   open on descriptor FD.  If possible, do it without changing the
   working directory.  Otherwise, resort to using save_cwd/fchdir,
   then (chmod|lchmod)/restore_cwd.  If either the save_cwd or the
   restore_cwd fails, then give a diagnostic and exit nonzero.
   Fail if FLAGS contains AT_SYMLINK_NOFOLLOW on a system lacking
   lchmod support.  */

#if HAVE_FCHMODAT
int
fchmodat (int dir, char const *file, mode_t mode, int flags)
{
  if (file && *file)
    flags &= ~AT_EMPTY_PATH;
  else if (! (flags & AT_EMPTY_PATH))
    {
      errno = ENOENT;
      return -1;
    }
  else if (! (flags & AT_SYMLINK_NOFOLLOW) && 0 <= dir)
    return fchmod (dir, mode);

# if HAVE_NEARLY_WORKING_FCHMODAT
  /* Correct the trailing slash handling.  */
  size_t len = strlen (file);
  if (len && file[len - 1] == '/')
    {
      struct stat st;
      if (fstatat (dir, file, &st, flags & AT_SYMLINK_NOFOLLOW) < 0)
        return -1;
      if (!S_ISDIR (st.st_mode))
        {
          errno = ENOTDIR;
          return -1;
        }
    }
# endif

# if NEED_FCHMODAT_NONSYMLINK_FIX
  if ((flags & ~AT_EMPTY_PATH) == AT_SYMLINK_NOFOLLOW)
    {
#  if HAVE_READLINKAT
#   ifdef O_PATH
      int fd;
      if (flags & AT_EMPTY_PATH)
        fd = dir;
      else
        {
          /* Open with O_NOFOLLOW, so we don't follow symlinks.
             See <https://sourceware.org/PR14578>.  */
          fd = openat (dir, file, O_PATH | O_NOFOLLOW | O_CLOEXEC);
          if (fd < 0)
            return fd;
        }

      int err;
      {
        int ret = issymlinkat (fd, "");
        if (ret > 0)
          err = EOPNOTSUPP;
        else if (ret == 0)
          {
            static char const fmt[] = "/proc/self/fd/%d";
            char buf[sizeof fmt - sizeof "%d" + INT_BUFSIZE_BOUND (int)];
            sprintf (buf, fmt, fd);
            err = chmod (buf, mode) == 0 ? 0 : errno == ENOENT ? -1 : errno;
          }
        else
          err = errno == ENOENT ? -1 : errno;
      }

      if (! (flags & AT_EMPTY_PATH))
        close (fd);

      errno = err;
      if (0 <= err)
        return err == 0 ? 0 : -1;
#   endif

      /* O_PATH + /proc is not supported.  */

      if (issymlinkat (dir, file ? file : "") > 0)
        {
          errno = EOPNOTSUPP;
          return -1;
        }
#  endif

      /* Fall back on orig_fchmodat without AT_SYMLINK_NOFOLLOW,
         despite a possible race.  */
      flags &= ~AT_SYMLINK_NOFOLLOW;
    }
# endif

  return orig_fchmodat (dir, file, mode, flags);
}
#else
# define AT_FUNC_NAME fchmodat
# define AT_FUNC_F1 lchmod
# define AT_FUNC_F2 chmod
# define AT_FUNC_USE_F1_COND AT_SYMLINK_NOFOLLOW
# define AT_FUNC_POST_FILE_PARAM_DECLS , mode_t mode, int flag
# define AT_FUNC_POST_FILE_ARGS        , mode
# include "at-func.c"
#endif
