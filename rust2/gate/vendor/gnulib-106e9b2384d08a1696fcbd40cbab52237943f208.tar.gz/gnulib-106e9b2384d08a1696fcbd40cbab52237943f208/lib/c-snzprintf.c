/* Formatted output to strings in C locale.
   Copyright (C) 2004, 2006-2026 Free Software Foundation, Inc.
   Written by Simon Josefsson and Paul Eggert.

   This file is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation; either version 2.1 of the
   License, or (at your option) any later version.

   This file is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

#include <config.h>

/* Specification.  */
#include "c-snprintf.h"

#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "c-vasnprintf.h"

ptrdiff_t
c_snzprintf (char *str, size_t size, const char *format, ...)
{
  va_list args;
  va_start (args, format);

  size_t lenbuf = size;
  char *output = c_vasnprintf (str, &lenbuf, format, args);
  size_t len = lenbuf;

  va_end (args);

  if (!output)
    return -1;

  if (output != str)
    {
      if (size)
        {
          size_t pruned_len = (len < size ? len : size - 1);
          memcpy (str, output, pruned_len);
          str[pruned_len] = '\0';
        }

      free (output);
    }

  if (len > PTRDIFF_MAX)
    {
      errno = ENOMEM;
      return -1;
    }

  return len;
}
